package neweventmanagementPack.neweventmanagementApp.Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import neweventmanagementPack.neweventmanagementApp.Entity.NewEvent;
import neweventmanagementPack.neweventmanagementApp.Service.NewEventService;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/events")
public class NewEventController {

    @Autowired
    private NewEventService newEventService;

    // Save a new event
    @PostMapping("/save")
    public ResponseEntity<NewEvent> saveEvent(@RequestBody NewEvent event) {
        NewEvent savedEvent = newEventService.saveEvent(event);
        return new ResponseEntity<>(savedEvent, HttpStatus.CREATED);
    }

    // Get all events
    @GetMapping("/all")
    public ResponseEntity<List<NewEvent>> getAllEvents() {
        List<NewEvent> events = newEventService.getAllEvents();
        return new ResponseEntity<>(events, HttpStatus.OK);
    }

    // Get event by ID
    @GetMapping("/{id}")
    public ResponseEntity<NewEvent> getEventById(@PathVariable Integer id) {
        NewEvent event = newEventService.getEventById(id);
        return new ResponseEntity<>(event, HttpStatus.OK);
    }

    // Update an existing event
    @PutMapping("/update/{id}")
    public ResponseEntity<NewEvent> updateEvent(@PathVariable Integer id, @RequestBody NewEvent updatedEvent) {
        NewEvent event = newEventService.updateEvent(id, updatedEvent);
        return new ResponseEntity<>(event, HttpStatus.OK);
    }

    // Delete event by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEvent(@PathVariable Integer id) {
        newEventService.deleteEvent(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
