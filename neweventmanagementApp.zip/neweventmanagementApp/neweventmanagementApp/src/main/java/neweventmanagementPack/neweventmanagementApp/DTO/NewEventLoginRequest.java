package neweventmanagementPack.neweventmanagementApp.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

public class NewEventLoginRequest {

    @NotEmpty(message = "Email must not be empty!")
    @Email(message = "Email is not valid!")
    private String emailId;

    @NotEmpty(message = "Password must not be empty!")
    @Size(min = 8, message = "Password length must be at least 8 characters!")
   // private String password;

	private Integer eventId;

	private String newEventAddress;

    // Getters and Setters
    public Integer getEventId() {
        return getEventId();
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public String getNewEventAddress() {
        return getNewEventAddress();
    }

    public void setNewEventAddress(String newEventAddress) {
        this.newEventAddress = newEventAddress;
    }
}
