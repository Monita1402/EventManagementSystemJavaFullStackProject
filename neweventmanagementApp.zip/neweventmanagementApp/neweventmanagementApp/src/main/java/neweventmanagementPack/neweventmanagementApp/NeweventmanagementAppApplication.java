package neweventmanagementPack.neweventmanagementApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeweventmanagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeweventmanagementAppApplication.class, args);
		System.out.println("Successful");
	}

}
