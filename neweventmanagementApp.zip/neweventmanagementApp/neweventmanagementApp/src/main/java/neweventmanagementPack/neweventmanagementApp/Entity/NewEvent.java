package neweventmanagementPack.neweventmanagementApp.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Min;

@Entity
@Table(name = "new_event_table")
public class NewEvent {
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer eventId;
    
    @NotEmpty
    @Size(min = 3, message = "New Event Name must contain at least 3 characters")
    private String newEventName;
    
    @NotEmpty(message = "New Event Address cannot be empty")
    private String newEventAddress;
    
    @NotEmpty(message = "New Event Date cannot be empty")
    private String newEventDate;
    
    @NotEmpty(message = "New Event Time cannot be empty")
    private String newEventTime;
    
    @Min(value = 0, message = "New Event Cost must be a positive value")
    private Double newEventCost;

    // Getters and Setters
    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public String getNewEventName() {
        return newEventName;
    }

    public void setNewEventName(String newEventName) {
        this.newEventName = newEventName;
    }

    public String getNewEventAddress() {
        return newEventAddress;
    }

    public void setNewEventAddress(String newEventAddress) {
        this.newEventAddress = newEventAddress;
    }

    public String getNewEventDate() {
        return newEventDate;
    }

    public void setNewEventDate(String newEventDate) {
        this.newEventDate = newEventDate;
    }

    public String getNewEventTime() {
        return newEventTime;
    }

    public void setNewEventTime(String newEventTime) {
        this.newEventTime = newEventTime;
    }

    public Double getNewEventCost() {
        return newEventCost;
    }

    public void setNewEventCost(Double newEventCost) {
        this.newEventCost = newEventCost;
    }

    // Constructors
    public NewEvent() {
        super();
    }

    public NewEvent(Integer eventId, 
                    @NotEmpty @Size(min = 3, message = "New Event Name must contain at least 3 characters") String newEventName, 
                    @NotEmpty(message = "New Event Address cannot be empty") String newEventAddress, 
                    @NotEmpty(message = "New Event Date cannot be empty") String newEventDate, 
                    @NotEmpty(message = "New Event Time cannot be empty") String newEventTime, 
                    @Min(value = 0, message = "New Event Cost must be a positive value") Double newEventCost) {
        super();
        this.eventId = eventId;
        this.newEventName = newEventName;
        this.newEventAddress = newEventAddress;
        this.newEventDate = newEventDate;
        this.newEventTime = newEventTime;
        this.newEventCost = newEventCost;
    }

    @Override
    public String toString() {
        return "NewEvent [eventId=" + eventId + ", newEventName=" + newEventName + ", newEventAddress=" + newEventAddress
                + ", newEventDate=" + newEventDate + ", newEventTime=" + newEventTime + ", newEventCost=" + newEventCost
                + "]";
    }
}
