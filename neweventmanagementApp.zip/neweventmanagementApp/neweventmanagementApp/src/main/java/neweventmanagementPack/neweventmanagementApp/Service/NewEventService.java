package neweventmanagementPack.neweventmanagementApp.Service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import neweventmanagementPack.neweventmanagementApp.Entity.NewEvent;
import neweventmanagementPack.neweventmanagementApp.Repository.NewEventRepository;

import java.util.List;

@Service
public class NewEventService {

    @Autowired
    private NewEventRepository newEventRepository;

    // Get all events
    public List<NewEvent> getAllEvents() {
        return newEventRepository.findAll();
    }

    // Get event by ID
    public NewEvent getEventById(Integer id) {
        return newEventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Event not found with ID: " + id));
    }

    // Save a new event
    public NewEvent saveEvent(NewEvent event) {
        return newEventRepository.save(event);
    }

    // Delete an event by ID
    public void deleteEvent(Integer id) {
        if (newEventRepository.existsById(id)) {
            newEventRepository.deleteById(id);
        } else {
            throw new RuntimeException("Event not found with ID: " + id);
        }
    }

    // Update an event
    public NewEvent updateEvent(Integer id, NewEvent updatedEvent) {
        NewEvent existingEvent = getEventById(id);
        existingEvent.setNewEventName(updatedEvent.getNewEventName());
        existingEvent.setNewEventAddress(updatedEvent.getNewEventAddress());
        existingEvent.setNewEventDate(updatedEvent.getNewEventDate());
        existingEvent.setNewEventTime(updatedEvent.getNewEventTime());
        existingEvent.setNewEventCost(updatedEvent.getNewEventCost());
        return newEventRepository.save(existingEvent);
    }
}
