package neweventmanagementPack.neweventmanagementApp.Repository;


import org.springframework.data.jpa.repository.JpaRepository;
import neweventmanagementPack.neweventmanagementApp.Entity.NewEvent;

public interface NewEventRepository extends JpaRepository<NewEvent, Integer> {
    // Add custom query methods if needed
}
