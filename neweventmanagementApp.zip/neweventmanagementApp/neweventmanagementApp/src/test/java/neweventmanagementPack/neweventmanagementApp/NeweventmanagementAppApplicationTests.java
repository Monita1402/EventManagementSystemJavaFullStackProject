package neweventmanagementPack.neweventmanagementApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeweventmanagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
