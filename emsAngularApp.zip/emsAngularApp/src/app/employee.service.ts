import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private api = 'http://localhost:8080/events'; // Spring Boot endpoint

  constructor(private http: HttpClient) { }

  saveEvent(eventData: any): Observable<any> {
    return this.http.post<any>(`${this.api}/save`, eventData);
  }

  // Get all events
  getAllEvents(): Observable<any[]> {
    return this.http.get<any[]>(`${this.api}/all`);
  }

  // Get event by ID
  getEventById(eventId: number): Observable<any> {
    return this.http.get<any>(`${this.api}/${eventId}`);
  }

  // Update an existing event
  updateEvent(eventId: number, updatedEvent: any): Observable<any> {
    return this.http.put<any>(`${this.api}/update/${eventId}`, updatedEvent);
  }

  // Delete an event by ID
  deleteEvent(eventId: number): Observable<void> {
    return this.http.delete<void>(`${this.api}/${eventId}`);
  }
  
}
