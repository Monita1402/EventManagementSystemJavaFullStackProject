export interface Employee {
  newEventId:any;
  newEventName : any ;
  newEventDate : any ;
  newEventTime : any ;
  newEventCost : any ;  
  newEventAddress:any;
 

 
}
