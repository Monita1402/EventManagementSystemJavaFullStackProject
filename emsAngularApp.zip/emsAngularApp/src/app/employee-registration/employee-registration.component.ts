import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-employee-registration',
  standalone: false,
  
  templateUrl: './employee-registration.component.html',
  styleUrl: './employee-registration.component.css'
})
export class EmployeeRegistrationComponent {

  employee = {
    eventId : 0,
    newEventName : '',
    newEventDate : '' ,
    newEventTime : '' ,
    newEventCost : 0 ,
    newEventPassword: '',
    newEventaddress:'',
    emailId: '',
  };

  constructor(private http: HttpClient) {}

  onSubmit() {
    this.http.post('http://localhost:8080/save', this.employee)
      .subscribe(
        (response:any) => {
          alert('Employee registered successfully!');
          console.log(response);
        },
        (error:any) => {
          alert('An error occurred while registering the employee.');
          console.error(error);
        }
      );
  }

}
