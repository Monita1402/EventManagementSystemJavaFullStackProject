import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-event',
  standalone: false,
  
  templateUrl: './edit-event.component.html',
  styleUrl: './edit-event.component.css'
})
export class EditEventComponent {

}
