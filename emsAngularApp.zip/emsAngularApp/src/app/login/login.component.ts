import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';



@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {


loginObj: any = {
username:'',
password:''
};

constructor(private router: Router) {}

// router = inject(Router);

onLogin() {
if(this.loginObj.username == "admin" && this.loginObj.password =="112233") {
this.router.navigateByUrl('home')
} else {
alert("Wrong Credentials")
}
}
}