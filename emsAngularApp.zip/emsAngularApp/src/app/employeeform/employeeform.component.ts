import { Component } from '@angular/core';
import { Employee } from '../employee.model';
import { EmployeeService } from '../employee.service';
import { NgForm } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-employeeform',
  standalone: false,
  
  templateUrl: './employeeform.component.html',
  styleUrl: './employeeform.component.css'
})
export class EmployeeformComponent {
 
    newEventName:any;
    newEventDate:any;
    newEventCost:any;
    newEventTime:any;
    newEventaddress:any;

  constructor(private employeeService: EmployeeService) { }


  // Method to handle form submission
    onSubmit() {
        let formdata={
          
            "newEventName":this.newEventName,
            "newEventAddress":this.newEventaddress,
            "newEventDate": this.newEventDate,
            "newEventTime": this.newEventTime,
            "newEventCost": this.newEventCost   
          
            
        }
   
      this.employeeService.saveEvent(formdata).subscribe(

        (response:any) => {
          console.log('Employee saved successfully:', response);
               //Display a success popup
          Swal.fire({
            title: 'Success!',
            text: 'Event saved successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
          });
          
        },
        (error:any) => {
           console.error('Error saving employee:', error);
                    // Display an error popup
                    Swal.fire({
                      title: 'Error!',
                      text: 'There was a problem saving the event. Please try again later.',
                      icon: 'error',
                      confirmButtonText: 'OK'
                    });
          
        }
      );
    }
  

}
