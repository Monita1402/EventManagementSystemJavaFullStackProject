import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { LoginComponent } from './login/login.component';
import { ViewEmpComponent } from './view-emp/view-emp.component';
import { ContactComponent } from './contact/contact.component';
import { SignupComponent } from './signup/signup.component';
import { EmployeeformComponent } from './employeeform/employeeform.component';
import { EditEmpComponent } from './edit-emp/edit-emp.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'viewEmp', component: ViewEmpComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'insertemp', component: EmployeeformComponent },
  { path: 'edit-emp/:id', component: EditEmpComponent }  ,
   { path: 'aboutus', component: AboutusComponent },

  { path: '', redirectTo: '/login', pathMatch: 'full' }, // Default Route

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
