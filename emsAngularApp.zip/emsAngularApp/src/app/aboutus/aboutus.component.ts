import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  standalone: false,
  
  templateUrl: './aboutus.component.html',
  styleUrl: './aboutus.component.css'
})
export class AboutusComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {
    // Logic for About Us page can go here if needed
  }
}