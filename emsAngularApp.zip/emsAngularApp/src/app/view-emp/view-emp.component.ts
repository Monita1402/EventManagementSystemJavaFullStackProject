import { Component } from '@angular/core';
import { Employee } from '../employee.model';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router'; // Import Router
@Component({
  selector: 'app-view-emp',
  standalone: false,
  
  templateUrl: './view-emp.component.html',
  styleUrl: './view-emp.component.css'
})
export class ViewEmpComponent {
  employees: any[] = []; // Array to hold fetched employees

  constructor(private employeeService: EmployeeService,private router: Router) {}


  ngOnInit(): void {
    this.loadEmployees();
  }
  // Fetch employees from backend
  loadEmployees(): void {
    this.employeeService.getAllEvents().subscribe(
      (data) => {
        this.employees = data; // Bind data to the employees array
        console.log('Employees fetched successfully:', data);
      },
      (error) => {
        console.error('Error fetching employees:', error);
      }
    );
  }
  


  editEmployee(employeeId: number): void {
    if (!employeeId) {
      console.error('Invalid employee ID');
      return;
    }
    this.router.navigate(['/edit-emp', employeeId]);
  }

  deleteEmployee(employeeId: number): void {
    if (!employeeId) {
      alert('Invalid employee ID');
      return;
    }

    const confirmDelete = confirm('Are you sure you want to delete this event?');
    if (confirmDelete) {
      this.employeeService.deleteEvent(employeeId).subscribe(
        () => {
          alert('Event deleted successfully!');
          this.loadEmployees();
        },
        (error) => {
          console.error('Error deleting event:', error);
        }
      );
    }
  }
}